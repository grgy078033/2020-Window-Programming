﻿namespace WindowsProgrammingProject
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.Item_textBox = new System.Windows.Forms.TextBox();
            this.Class_label = new System.Windows.Forms.Label();
            this.Class_comboBox = new System.Windows.Forms.ComboBox();
            this.Item_label = new System.Windows.Forms.Label();
            this.Price_textBox = new System.Windows.Forms.TextBox();
            this.Else_textBox = new System.Windows.Forms.TextBox();
            this.Else_label = new System.Windows.Forms.Label();
            this.Price_label = new System.Windows.Forms.Label();
            this.Perform_textBox = new System.Windows.Forms.TextBox();
            this.Year_comboBox = new System.Windows.Forms.ComboBox();
            this.Month_comboBox = new System.Windows.Forms.ComboBox();
            this.Day_comboBox = new System.Windows.Forms.ComboBox();
            this.Year_label = new System.Windows.Forms.Label();
            this.Day_label = new System.Windows.Forms.Label();
            this.Month_label = new System.Windows.Forms.Label();
            this.Time_label = new System.Windows.Forms.Label();
            this.Search_label = new System.Windows.Forms.Label();
            this.Statistic_label = new System.Windows.Forms.Label();
            this.Game_label = new System.Windows.Forms.Label();
            this.Cust_label = new System.Windows.Forms.Label();
            this.Budget_label = new System.Windows.Forms.Label();
            this.ClassSetting_label = new System.Windows.Forms.Label();
            this.Line1_label = new System.Windows.Forms.Label();
            this.Title_label = new System.Windows.Forms.Label();
            this.Back_btn = new System.Windows.Forms.Button();
            this.Game_pictureBox = new System.Windows.Forms.PictureBox();
            this.ClassSetting_pictureBox = new System.Windows.Forms.PictureBox();
            this.Budget_pictureBox = new System.Windows.Forms.PictureBox();
            this.Statistic_pictureBox = new System.Windows.Forms.PictureBox();
            this.Cust_pictureBox = new System.Windows.Forms.PictureBox();
            this.Search_pictureBox = new System.Windows.Forms.PictureBox();
            this.Add_pictureBox = new System.Windows.Forms.PictureBox();
            this.Setting_pictureBox = new System.Windows.Forms.PictureBox();
            this.Class_dataGridView = new System.Windows.Forms.DataGridView();
            this.類別DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.品項DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.價格DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.年DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.月DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.日DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.備註DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.記帳BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.trackDataSet = new WindowsProgrammingProject.trackDataSet();
            this.記帳TableAdapter = new WindowsProgrammingProject.trackDataSetTableAdapters.記帳TableAdapter();
            this.class_checkbox = new System.Windows.Forms.CheckBox();
            this.font_label = new System.Windows.Forms.Label();
            this.color_label = new System.Windows.Forms.Label();
            this.example_label = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.delete_class = new System.Windows.Forms.Label();
            this.sort_class = new System.Windows.Forms.Label();
            this.Sort_comboBox = new System.Windows.Forms.ComboBox();
            this.label_sort_exp1 = new System.Windows.Forms.Label();
            this.label_sort_exp2 = new System.Windows.Forms.Label();
            this.data_chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Pie_radioButtom = new System.Windows.Forms.RadioButton();
            this.Bar_radioButtom = new System.Windows.Forms.RadioButton();
            this.Line_radioButtom = new System.Windows.Forms.RadioButton();
            this.Histogram_radioButtom = new System.Windows.Forms.RadioButton();
            this.budget_textbox = new System.Windows.Forms.TextBox();
            this.set_budget_buttom = new System.Windows.Forms.Button();
            this.current_month_budget = new System.Windows.Forms.Label();
            this.budgetSet_label = new System.Windows.Forms.Label();
            this.money1 = new System.Windows.Forms.Label();
            this.money2 = new System.Windows.Forms.Label();
            this.budget_progressBar = new System.Windows.Forms.ProgressBar();
            this.ProgressBar_label = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Game_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClassSetting_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Budget_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Statistic_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cust_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Search_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Add_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Setting_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Class_dataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.記帳BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.data_chart)).BeginInit();
            this.SuspendLayout();
            // 
            // Item_textBox
            // 
            this.Item_textBox.BackColor = System.Drawing.SystemColors.Window;
            this.Item_textBox.Location = new System.Drawing.Point(96, 155);
            this.Item_textBox.Multiline = true;
            this.Item_textBox.Name = "Item_textBox";
            this.Item_textBox.Size = new System.Drawing.Size(226, 22);
            this.Item_textBox.TabIndex = 7;
            // 
            // Class_label
            // 
            this.Class_label.AutoSize = true;
            this.Class_label.Location = new System.Drawing.Point(35, 116);
            this.Class_label.Name = "Class_label";
            this.Class_label.Size = new System.Drawing.Size(37, 15);
            this.Class_label.TabIndex = 5;
            this.Class_label.Text = "類別";
            // 
            // Class_comboBox
            // 
            this.Class_comboBox.FormattingEnabled = true;
            this.Class_comboBox.Location = new System.Drawing.Point(96, 113);
            this.Class_comboBox.Name = "Class_comboBox";
            this.Class_comboBox.Size = new System.Drawing.Size(226, 23);
            this.Class_comboBox.TabIndex = 6;
            this.Class_comboBox.SelectedIndexChanged += new System.EventHandler(this.Class_comboBox_SelectedIndexChanged);
            // 
            // Item_label
            // 
            this.Item_label.AutoSize = true;
            this.Item_label.Location = new System.Drawing.Point(35, 157);
            this.Item_label.Name = "Item_label";
            this.Item_label.Size = new System.Drawing.Size(37, 15);
            this.Item_label.TabIndex = 7;
            this.Item_label.Text = "品項";
            // 
            // Price_textBox
            // 
            this.Price_textBox.BackColor = System.Drawing.SystemColors.Window;
            this.Price_textBox.Location = new System.Drawing.Point(96, 197);
            this.Price_textBox.Multiline = true;
            this.Price_textBox.Name = "Price_textBox";
            this.Price_textBox.Size = new System.Drawing.Size(226, 22);
            this.Price_textBox.TabIndex = 8;
            // 
            // Else_textBox
            // 
            this.Else_textBox.BackColor = System.Drawing.SystemColors.Window;
            this.Else_textBox.Location = new System.Drawing.Point(96, 238);
            this.Else_textBox.Multiline = true;
            this.Else_textBox.Name = "Else_textBox";
            this.Else_textBox.Size = new System.Drawing.Size(181, 22);
            this.Else_textBox.TabIndex = 9;
            // 
            // Else_label
            // 
            this.Else_label.AutoSize = true;
            this.Else_label.Location = new System.Drawing.Point(35, 241);
            this.Else_label.Name = "Else_label";
            this.Else_label.Size = new System.Drawing.Size(37, 15);
            this.Else_label.TabIndex = 10;
            this.Else_label.Text = "備註";
            // 
            // Price_label
            // 
            this.Price_label.AutoSize = true;
            this.Price_label.Location = new System.Drawing.Point(35, 199);
            this.Price_label.Name = "Price_label";
            this.Price_label.Size = new System.Drawing.Size(37, 15);
            this.Price_label.TabIndex = 11;
            this.Price_label.Text = "價格";
            // 
            // Perform_textBox
            // 
            this.Perform_textBox.BackColor = System.Drawing.SystemColors.Control;
            this.Perform_textBox.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Perform_textBox.Location = new System.Drawing.Point(22, 277);
            this.Perform_textBox.Multiline = true;
            this.Perform_textBox.Name = "Perform_textBox";
            this.Perform_textBox.Size = new System.Drawing.Size(312, 279);
            this.Perform_textBox.TabIndex = 14;
            // 
            // Year_comboBox
            // 
            this.Year_comboBox.FormattingEnabled = true;
            this.Year_comboBox.Items.AddRange(new object[] {
            "2020",
            "2021",
            "2022",
            "2023",
            "2024",
            "2025",
            "2026",
            "2027",
            "2028",
            "2029",
            "2030",
            "2031",
            "2032",
            "2033",
            "2034",
            "2035",
            "2036",
            "2037",
            "2038",
            "2039",
            "2040",
            "2041",
            "2042",
            "2043",
            "2044",
            "2045",
            "2046",
            "2047",
            "2048",
            "2049",
            "2050"});
            this.Year_comboBox.Location = new System.Drawing.Point(34, 70);
            this.Year_comboBox.Name = "Year_comboBox";
            this.Year_comboBox.Size = new System.Drawing.Size(87, 23);
            this.Year_comboBox.TabIndex = 10;
            this.Year_comboBox.SelectedIndexChanged += new System.EventHandler(this.Year_comboBox_SelectedIndexChanged);
            // 
            // Month_comboBox
            // 
            this.Month_comboBox.FormattingEnabled = true;
            this.Month_comboBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.Month_comboBox.Location = new System.Drawing.Point(154, 70);
            this.Month_comboBox.Name = "Month_comboBox";
            this.Month_comboBox.Size = new System.Drawing.Size(54, 23);
            this.Month_comboBox.TabIndex = 11;
            this.Month_comboBox.SelectedIndexChanged += new System.EventHandler(this.Month_comboBox_SelectedIndexChanged);
            // 
            // Day_comboBox
            // 
            this.Day_comboBox.FormattingEnabled = true;
            this.Day_comboBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.Day_comboBox.Location = new System.Drawing.Point(241, 70);
            this.Day_comboBox.Name = "Day_comboBox";
            this.Day_comboBox.Size = new System.Drawing.Size(54, 23);
            this.Day_comboBox.TabIndex = 12;
            // 
            // Year_label
            // 
            this.Year_label.AutoSize = true;
            this.Year_label.Location = new System.Drawing.Point(125, 74);
            this.Year_label.Name = "Year_label";
            this.Year_label.Size = new System.Drawing.Size(22, 15);
            this.Year_label.TabIndex = 16;
            this.Year_label.Text = "年";
            // 
            // Day_label
            // 
            this.Day_label.AutoSize = true;
            this.Day_label.Location = new System.Drawing.Point(300, 74);
            this.Day_label.Name = "Day_label";
            this.Day_label.Size = new System.Drawing.Size(22, 15);
            this.Day_label.TabIndex = 17;
            this.Day_label.Text = "日";
            // 
            // Month_label
            // 
            this.Month_label.AutoSize = true;
            this.Month_label.Location = new System.Drawing.Point(212, 74);
            this.Month_label.Name = "Month_label";
            this.Month_label.Size = new System.Drawing.Size(22, 15);
            this.Month_label.TabIndex = 18;
            this.Month_label.Text = "月";
            // 
            // Time_label
            // 
            this.Time_label.AutoSize = true;
            this.Time_label.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Time_label.Location = new System.Drawing.Point(33, 22);
            this.Time_label.Name = "Time_label";
            this.Time_label.Size = new System.Drawing.Size(72, 25);
            this.Time_label.TabIndex = 20;
            this.Time_label.Text = "00000";
            // 
            // Search_label
            // 
            this.Search_label.Location = new System.Drawing.Point(36, 177);
            this.Search_label.Name = "Search_label";
            this.Search_label.Size = new System.Drawing.Size(71, 19);
            this.Search_label.TabIndex = 27;
            this.Search_label.Text = "搜尋紀錄";
            // 
            // Statistic_label
            // 
            this.Statistic_label.Location = new System.Drawing.Point(147, 177);
            this.Statistic_label.Name = "Statistic_label";
            this.Statistic_label.Size = new System.Drawing.Size(71, 19);
            this.Statistic_label.TabIndex = 28;
            this.Statistic_label.Text = "支出分析";
            // 
            // Game_label
            // 
            this.Game_label.Location = new System.Drawing.Point(258, 343);
            this.Game_label.Name = "Game_label";
            this.Game_label.Size = new System.Drawing.Size(71, 19);
            this.Game_label.TabIndex = 29;
            this.Game_label.Text = "遊戲";
            this.Game_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Cust_label
            // 
            this.Cust_label.Location = new System.Drawing.Point(147, 343);
            this.Cust_label.Name = "Cust_label";
            this.Cust_label.Size = new System.Drawing.Size(71, 19);
            this.Cust_label.TabIndex = 30;
            this.Cust_label.Text = "介面調整";
            // 
            // Budget_label
            // 
            this.Budget_label.Location = new System.Drawing.Point(258, 177);
            this.Budget_label.Name = "Budget_label";
            this.Budget_label.Size = new System.Drawing.Size(71, 19);
            this.Budget_label.TabIndex = 31;
            this.Budget_label.Text = "顯示預算";
            // 
            // ClassSetting_label
            // 
            this.ClassSetting_label.Location = new System.Drawing.Point(36, 343);
            this.ClassSetting_label.Name = "ClassSetting_label";
            this.ClassSetting_label.Size = new System.Drawing.Size(71, 19);
            this.ClassSetting_label.TabIndex = 32;
            this.ClassSetting_label.Text = "設定類別";
            // 
            // Line1_label
            // 
            this.Line1_label.Location = new System.Drawing.Point(5, 508);
            this.Line1_label.Name = "Line1_label";
            this.Line1_label.Size = new System.Drawing.Size(356, 19);
            this.Line1_label.TabIndex = 33;
            this.Line1_label.Text = "_________________________________________________";
            // 
            // Title_label
            // 
            this.Title_label.AutoSize = true;
            this.Title_label.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Title_label.Location = new System.Drawing.Point(25, 27);
            this.Title_label.Name = "Title_label";
            this.Title_label.Size = new System.Drawing.Size(51, 20);
            this.Title_label.TabIndex = 45;
            this.Title_label.Text = "標題";
            // 
            // Back_btn
            // 
            this.Back_btn.BackColor = System.Drawing.SystemColors.HighlightText;
            this.Back_btn.Location = new System.Drawing.Point(269, 22);
            this.Back_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Back_btn.Name = "Back_btn";
            this.Back_btn.Size = new System.Drawing.Size(67, 29);
            this.Back_btn.TabIndex = 34;
            this.Back_btn.Text = "返回";
            this.Back_btn.UseVisualStyleBackColor = false;
            this.Back_btn.Click += new System.EventHandler(this.Back_btn_Click);
            // 
            // Game_pictureBox
            // 
            this.Game_pictureBox.Image = global::WindowsProgrammingProject.Properties.Resources.game;
            this.Game_pictureBox.Location = new System.Drawing.Point(249, 250);
            this.Game_pictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Game_pictureBox.Name = "Game_pictureBox";
            this.Game_pictureBox.Size = new System.Drawing.Size(89, 83);
            this.Game_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Game_pictureBox.TabIndex = 57;
            this.Game_pictureBox.TabStop = false;
            this.Game_pictureBox.Click += new System.EventHandler(this.Game_pictureBox_Click);
            // 
            // ClassSetting_pictureBox
            // 
            this.ClassSetting_pictureBox.Image = global::WindowsProgrammingProject.Properties.Resources.classsetting;
            this.ClassSetting_pictureBox.Location = new System.Drawing.Point(27, 250);
            this.ClassSetting_pictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ClassSetting_pictureBox.Name = "ClassSetting_pictureBox";
            this.ClassSetting_pictureBox.Size = new System.Drawing.Size(89, 83);
            this.ClassSetting_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ClassSetting_pictureBox.TabIndex = 56;
            this.ClassSetting_pictureBox.TabStop = false;
            this.ClassSetting_pictureBox.Click += new System.EventHandler(this.ClassSetting_pictureBox_Click);
            // 
            // Budget_pictureBox
            // 
            this.Budget_pictureBox.Image = global::WindowsProgrammingProject.Properties.Resources.budget;
            this.Budget_pictureBox.Location = new System.Drawing.Point(249, 83);
            this.Budget_pictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Budget_pictureBox.Name = "Budget_pictureBox";
            this.Budget_pictureBox.Size = new System.Drawing.Size(89, 83);
            this.Budget_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Budget_pictureBox.TabIndex = 55;
            this.Budget_pictureBox.TabStop = false;
            this.Budget_pictureBox.Click += new System.EventHandler(this.Budget_pictureBox_Click);
            // 
            // Statistic_pictureBox
            // 
            this.Statistic_pictureBox.Image = global::WindowsProgrammingProject.Properties.Resources.statistic;
            this.Statistic_pictureBox.Location = new System.Drawing.Point(138, 83);
            this.Statistic_pictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Statistic_pictureBox.Name = "Statistic_pictureBox";
            this.Statistic_pictureBox.Size = new System.Drawing.Size(89, 83);
            this.Statistic_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Statistic_pictureBox.TabIndex = 54;
            this.Statistic_pictureBox.TabStop = false;
            this.Statistic_pictureBox.Click += new System.EventHandler(this.Statistic_pictureBox_Click);
            // 
            // Cust_pictureBox
            // 
            this.Cust_pictureBox.Image = global::WindowsProgrammingProject.Properties.Resources.data;
            this.Cust_pictureBox.Location = new System.Drawing.Point(138, 250);
            this.Cust_pictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Cust_pictureBox.Name = "Cust_pictureBox";
            this.Cust_pictureBox.Size = new System.Drawing.Size(89, 83);
            this.Cust_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Cust_pictureBox.TabIndex = 53;
            this.Cust_pictureBox.TabStop = false;
            this.Cust_pictureBox.Click += new System.EventHandler(this.Cust_pictureBox_Click);
            // 
            // Search_pictureBox
            // 
            this.Search_pictureBox.Image = global::WindowsProgrammingProject.Properties.Resources.search;
            this.Search_pictureBox.Location = new System.Drawing.Point(27, 83);
            this.Search_pictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Search_pictureBox.Name = "Search_pictureBox";
            this.Search_pictureBox.Size = new System.Drawing.Size(89, 83);
            this.Search_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Search_pictureBox.TabIndex = 52;
            this.Search_pictureBox.TabStop = false;
            this.Search_pictureBox.Click += new System.EventHandler(this.Search_pictureBox_Click);
            // 
            // Add_pictureBox
            // 
            this.Add_pictureBox.Image = global::WindowsProgrammingProject.Properties.Resources.add;
            this.Add_pictureBox.Location = new System.Drawing.Point(298, 231);
            this.Add_pictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Add_pictureBox.Name = "Add_pictureBox";
            this.Add_pictureBox.Size = new System.Drawing.Size(44, 42);
            this.Add_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Add_pictureBox.TabIndex = 51;
            this.Add_pictureBox.TabStop = false;
            this.Add_pictureBox.Click += new System.EventHandler(this.Add_pictureBox_Click);
            // 
            // Setting_pictureBox
            // 
            this.Setting_pictureBox.Image = global::WindowsProgrammingProject.Properties.Resources.setting;
            this.Setting_pictureBox.Location = new System.Drawing.Point(298, 14);
            this.Setting_pictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Setting_pictureBox.Name = "Setting_pictureBox";
            this.Setting_pictureBox.Size = new System.Drawing.Size(44, 42);
            this.Setting_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Setting_pictureBox.TabIndex = 50;
            this.Setting_pictureBox.TabStop = false;
            this.Setting_pictureBox.Click += new System.EventHandler(this.Setting_pictureBox_Click);
            // 
            // Class_dataGridView
            // 
            this.Class_dataGridView.AutoGenerateColumns = false;
            this.Class_dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Class_dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.類別DataGridViewTextBoxColumn,
            this.品項DataGridViewTextBoxColumn,
            this.價格DataGridViewTextBoxColumn,
            this.年DataGridViewTextBoxColumn,
            this.月DataGridViewTextBoxColumn,
            this.日DataGridViewTextBoxColumn,
            this.備註DataGridViewTextBoxColumn});
            this.Class_dataGridView.DataSource = this.記帳BindingSource;
            this.Class_dataGridView.Location = new System.Drawing.Point(22, 158);
            this.Class_dataGridView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Class_dataGridView.Name = "Class_dataGridView";
            this.Class_dataGridView.RowTemplate.Height = 31;
            this.Class_dataGridView.Size = new System.Drawing.Size(687, 398);
            this.Class_dataGridView.TabIndex = 58;
            // 
            // 類別DataGridViewTextBoxColumn
            // 
            this.類別DataGridViewTextBoxColumn.DataPropertyName = "類別";
            this.類別DataGridViewTextBoxColumn.HeaderText = "類別";
            this.類別DataGridViewTextBoxColumn.Name = "類別DataGridViewTextBoxColumn";
            // 
            // 品項DataGridViewTextBoxColumn
            // 
            this.品項DataGridViewTextBoxColumn.DataPropertyName = "品項";
            this.品項DataGridViewTextBoxColumn.HeaderText = "品項";
            this.品項DataGridViewTextBoxColumn.Name = "品項DataGridViewTextBoxColumn";
            // 
            // 價格DataGridViewTextBoxColumn
            // 
            this.價格DataGridViewTextBoxColumn.DataPropertyName = "價格";
            this.價格DataGridViewTextBoxColumn.HeaderText = "價格";
            this.價格DataGridViewTextBoxColumn.Name = "價格DataGridViewTextBoxColumn";
            // 
            // 年DataGridViewTextBoxColumn
            // 
            this.年DataGridViewTextBoxColumn.DataPropertyName = "年";
            this.年DataGridViewTextBoxColumn.HeaderText = "年";
            this.年DataGridViewTextBoxColumn.Name = "年DataGridViewTextBoxColumn";
            // 
            // 月DataGridViewTextBoxColumn
            // 
            this.月DataGridViewTextBoxColumn.DataPropertyName = "月";
            this.月DataGridViewTextBoxColumn.HeaderText = "月";
            this.月DataGridViewTextBoxColumn.Name = "月DataGridViewTextBoxColumn";
            // 
            // 日DataGridViewTextBoxColumn
            // 
            this.日DataGridViewTextBoxColumn.DataPropertyName = "日";
            this.日DataGridViewTextBoxColumn.HeaderText = "日";
            this.日DataGridViewTextBoxColumn.Name = "日DataGridViewTextBoxColumn";
            // 
            // 備註DataGridViewTextBoxColumn
            // 
            this.備註DataGridViewTextBoxColumn.DataPropertyName = "備註";
            this.備註DataGridViewTextBoxColumn.HeaderText = "備註";
            this.備註DataGridViewTextBoxColumn.Name = "備註DataGridViewTextBoxColumn";
            // 
            // 記帳BindingSource
            // 
            this.記帳BindingSource.DataMember = "記帳";
            this.記帳BindingSource.DataSource = this.trackDataSet;
            // 
            // trackDataSet
            // 
            this.trackDataSet.DataSetName = "trackDataSet";
            this.trackDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // 記帳TableAdapter
            // 
            this.記帳TableAdapter.ClearBeforeFill = true;
            // 
            // class_checkbox
            // 
            this.class_checkbox.AutoSize = true;
            this.class_checkbox.Checked = true;
            this.class_checkbox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.class_checkbox.Location = new System.Drawing.Point(341, 115);
            this.class_checkbox.Name = "class_checkbox";
            this.class_checkbox.Size = new System.Drawing.Size(89, 19);
            this.class_checkbox.TabIndex = 59;
            this.class_checkbox.Text = "類別搜尋";
            this.class_checkbox.UseVisualStyleBackColor = true;
            this.class_checkbox.CheckedChanged += new System.EventHandler(this.class_checkbox_CheckedChanged);
            // 
            // font_label
            // 
            this.font_label.AutoSize = true;
            this.font_label.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.font_label.Location = new System.Drawing.Point(64, 75);
            this.font_label.Name = "font_label";
            this.font_label.Size = new System.Drawing.Size(106, 24);
            this.font_label.TabIndex = 60;
            this.font_label.Text = "文字字體";
            this.font_label.Click += new System.EventHandler(this.font_label_Click);
            // 
            // color_label
            // 
            this.color_label.AutoSize = true;
            this.color_label.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.color_label.ForeColor = System.Drawing.SystemColors.ControlText;
            this.color_label.Location = new System.Drawing.Point(66, 124);
            this.color_label.Name = "color_label";
            this.color_label.Size = new System.Drawing.Size(106, 24);
            this.color_label.TabIndex = 61;
            this.color_label.Text = "文字顏色";
            this.color_label.Click += new System.EventHandler(this.color_label_Click);
            // 
            // example_label
            // 
            this.example_label.AutoSize = true;
            this.example_label.Location = new System.Drawing.Point(73, 180);
            this.example_label.Name = "example_label";
            this.example_label.Size = new System.Drawing.Size(67, 15);
            this.example_label.TabIndex = 62;
            this.example_label.Text = "我是範例";
            // 
            // delete_class
            // 
            this.delete_class.AutoSize = true;
            this.delete_class.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.delete_class.Location = new System.Drawing.Point(66, 75);
            this.delete_class.Name = "delete_class";
            this.delete_class.Size = new System.Drawing.Size(106, 24);
            this.delete_class.TabIndex = 63;
            this.delete_class.Text = "刪除類別";
            this.delete_class.Click += new System.EventHandler(this.delete_class_Click);
            // 
            // sort_class
            // 
            this.sort_class.AutoSize = true;
            this.sort_class.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.sort_class.ForeColor = System.Drawing.SystemColors.ControlText;
            this.sort_class.Location = new System.Drawing.Point(64, 124);
            this.sort_class.Name = "sort_class";
            this.sort_class.Size = new System.Drawing.Size(106, 24);
            this.sort_class.TabIndex = 64;
            this.sort_class.Text = "類別排序";
            this.sort_class.Click += new System.EventHandler(this.sort_class_Click);
            // 
            // Sort_comboBox
            // 
            this.Sort_comboBox.FormattingEnabled = true;
            this.Sort_comboBox.Location = new System.Drawing.Point(237, 79);
            this.Sort_comboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Sort_comboBox.Name = "Sort_comboBox";
            this.Sort_comboBox.Size = new System.Drawing.Size(108, 23);
            this.Sort_comboBox.TabIndex = 67;
            // 
            // label_sort_exp1
            // 
            this.label_sort_exp1.AutoSize = true;
            this.label_sort_exp1.Location = new System.Drawing.Point(65, 81);
            this.label_sort_exp1.Name = "label_sort_exp1";
            this.label_sort_exp1.Size = new System.Drawing.Size(157, 15);
            this.label_sort_exp1.TabIndex = 66;
            this.label_sort_exp1.Text = "類別要移動至第幾個：";
            // 
            // label_sort_exp2
            // 
            this.label_sort_exp2.AutoSize = true;
            this.label_sort_exp2.Location = new System.Drawing.Point(65, 115);
            this.label_sort_exp2.Name = "label_sort_exp2";
            this.label_sort_exp2.Size = new System.Drawing.Size(142, 15);
            this.label_sort_exp2.TabIndex = 65;
            this.label_sort_exp2.Text = "選取要移動的類別：";
            // 
            // data_chart
            // 
            chartArea2.Name = "ChartArea1";
            this.data_chart.ChartAreas.Add(chartArea2);
            legend2.Enabled = false;
            legend2.Name = "Legend1";
            this.data_chart.Legends.Add(legend2);
            this.data_chart.Location = new System.Drawing.Point(34, 116);
            this.data_chart.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.data_chart.Name = "data_chart";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series2.IsValueShownAsLabel = true;
            series2.IsXValueIndexed = true;
            series2.Label = "#VALX: #VAL";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.data_chart.Series.Add(series2);
            this.data_chart.Size = new System.Drawing.Size(675, 440);
            this.data_chart.TabIndex = 68;
            this.data_chart.Text = "chart1";
            // 
            // Pie_radioButtom
            // 
            this.Pie_radioButtom.AutoSize = true;
            this.Pie_radioButtom.Checked = true;
            this.Pie_radioButtom.Location = new System.Drawing.Point(249, 70);
            this.Pie_radioButtom.Name = "Pie_radioButtom";
            this.Pie_radioButtom.Size = new System.Drawing.Size(73, 19);
            this.Pie_radioButtom.TabIndex = 69;
            this.Pie_radioButtom.TabStop = true;
            this.Pie_radioButtom.Text = "圓餅圖";
            this.Pie_radioButtom.UseVisualStyleBackColor = true;
            this.Pie_radioButtom.CheckedChanged += new System.EventHandler(this.Pie_radioButtom_CheckedChanged);
            // 
            // Bar_radioButtom
            // 
            this.Bar_radioButtom.AutoSize = true;
            this.Bar_radioButtom.Location = new System.Drawing.Point(359, 70);
            this.Bar_radioButtom.Name = "Bar_radioButtom";
            this.Bar_radioButtom.Size = new System.Drawing.Size(73, 19);
            this.Bar_radioButtom.TabIndex = 70;
            this.Bar_radioButtom.TabStop = true;
            this.Bar_radioButtom.Text = "長條圖";
            this.Bar_radioButtom.UseVisualStyleBackColor = true;
            this.Bar_radioButtom.CheckedChanged += new System.EventHandler(this.Bar_radioButtom_CheckedChanged);
            // 
            // Line_radioButtom
            // 
            this.Line_radioButtom.AutoSize = true;
            this.Line_radioButtom.Location = new System.Drawing.Point(470, 69);
            this.Line_radioButtom.Name = "Line_radioButtom";
            this.Line_radioButtom.Size = new System.Drawing.Size(73, 19);
            this.Line_radioButtom.TabIndex = 71;
            this.Line_radioButtom.TabStop = true;
            this.Line_radioButtom.Text = "折線圖";
            this.Line_radioButtom.UseVisualStyleBackColor = true;
            this.Line_radioButtom.CheckedChanged += new System.EventHandler(this.Line_radioButtom_CheckedChanged);
            // 
            // Histogram_radioButtom
            // 
            this.Histogram_radioButtom.AutoSize = true;
            this.Histogram_radioButtom.Location = new System.Drawing.Point(581, 68);
            this.Histogram_radioButtom.Name = "Histogram_radioButtom";
            this.Histogram_radioButtom.Size = new System.Drawing.Size(73, 19);
            this.Histogram_radioButtom.TabIndex = 72;
            this.Histogram_radioButtom.TabStop = true;
            this.Histogram_radioButtom.Text = "直方圖";
            this.Histogram_radioButtom.UseVisualStyleBackColor = true;
            this.Histogram_radioButtom.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // budget_textbox
            // 
            this.budget_textbox.Location = new System.Drawing.Point(34, 109);
            this.budget_textbox.Name = "budget_textbox";
            this.budget_textbox.Size = new System.Drawing.Size(87, 25);
            this.budget_textbox.TabIndex = 73;
            // 
            // set_budget_buttom
            // 
            this.set_budget_buttom.AutoSize = true;
            this.set_budget_buttom.Location = new System.Drawing.Point(141, 109);
            this.set_budget_buttom.Name = "set_budget_buttom";
            this.set_budget_buttom.Size = new System.Drawing.Size(77, 25);
            this.set_budget_buttom.TabIndex = 74;
            this.set_budget_buttom.Text = "設定預算";
            this.set_budget_buttom.UseVisualStyleBackColor = true;
            this.set_budget_buttom.Click += new System.EventHandler(this.set_budget_buttom_Click_1);
            // 
            // current_month_budget
            // 
            this.current_month_budget.AutoSize = true;
            this.current_month_budget.Location = new System.Drawing.Point(38, 155);
            this.current_month_budget.Name = "current_month_budget";
            this.current_month_budget.Size = new System.Drawing.Size(75, 15);
            this.current_month_budget.TabIndex = 75;
            this.current_month_budget.Text = "本月花費 :";
            // 
            // budgetSet_label
            // 
            this.budgetSet_label.AutoSize = true;
            this.budgetSet_label.Location = new System.Drawing.Point(38, 184);
            this.budgetSet_label.Name = "budgetSet_label";
            this.budgetSet_label.Size = new System.Drawing.Size(75, 15);
            this.budgetSet_label.TabIndex = 76;
            this.budgetSet_label.Text = "預算金額 :";
            // 
            // money1
            // 
            this.money1.AutoSize = true;
            this.money1.Location = new System.Drawing.Point(121, 156);
            this.money1.Name = "money1";
            this.money1.Size = new System.Drawing.Size(0, 15);
            this.money1.TabIndex = 77;
            // 
            // money2
            // 
            this.money2.AutoSize = true;
            this.money2.Location = new System.Drawing.Point(121, 185);
            this.money2.Name = "money2";
            this.money2.Size = new System.Drawing.Size(0, 15);
            this.money2.TabIndex = 78;
            // 
            // budget_progressBar
            // 
            this.budget_progressBar.BackColor = System.Drawing.SystemColors.ControlLight;
            this.budget_progressBar.Location = new System.Drawing.Point(41, 225);
            this.budget_progressBar.Name = "budget_progressBar";
            this.budget_progressBar.Size = new System.Drawing.Size(281, 23);
            this.budget_progressBar.TabIndex = 79;
            // 
            // ProgressBar_label
            // 
            this.ProgressBar_label.AutoSize = true;
            this.ProgressBar_label.Location = new System.Drawing.Point(152, 229);
            this.ProgressBar_label.Name = "ProgressBar_label";
            this.ProgressBar_label.Size = new System.Drawing.Size(0, 15);
            this.ProgressBar_label.TabIndex = 80;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(736, 595);
            this.Controls.Add(this.ProgressBar_label);
            this.Controls.Add(this.money2);
            this.Controls.Add(this.money1);
            this.Controls.Add(this.budgetSet_label);
            this.Controls.Add(this.current_month_budget);
            this.Controls.Add(this.set_budget_buttom);
            this.Controls.Add(this.budget_textbox);
            this.Controls.Add(this.Histogram_radioButtom);
            this.Controls.Add(this.Line_radioButtom);
            this.Controls.Add(this.Bar_radioButtom);
            this.Controls.Add(this.Pie_radioButtom);
            this.Controls.Add(this.Sort_comboBox);
            this.Controls.Add(this.label_sort_exp1);
            this.Controls.Add(this.label_sort_exp2);
            this.Controls.Add(this.sort_class);
            this.Controls.Add(this.delete_class);
            this.Controls.Add(this.example_label);
            this.Controls.Add(this.color_label);
            this.Controls.Add(this.font_label);
            this.Controls.Add(this.class_checkbox);
            this.Controls.Add(this.Game_pictureBox);
            this.Controls.Add(this.ClassSetting_pictureBox);
            this.Controls.Add(this.Budget_pictureBox);
            this.Controls.Add(this.Statistic_pictureBox);
            this.Controls.Add(this.Cust_pictureBox);
            this.Controls.Add(this.Search_pictureBox);
            this.Controls.Add(this.Add_pictureBox);
            this.Controls.Add(this.Setting_pictureBox);
            this.Controls.Add(this.Title_label);
            this.Controls.Add(this.Back_btn);
            this.Controls.Add(this.Line1_label);
            this.Controls.Add(this.ClassSetting_label);
            this.Controls.Add(this.Budget_label);
            this.Controls.Add(this.Cust_label);
            this.Controls.Add(this.Game_label);
            this.Controls.Add(this.Statistic_label);
            this.Controls.Add(this.Search_label);
            this.Controls.Add(this.Time_label);
            this.Controls.Add(this.Month_label);
            this.Controls.Add(this.Day_label);
            this.Controls.Add(this.Year_label);
            this.Controls.Add(this.Day_comboBox);
            this.Controls.Add(this.Month_comboBox);
            this.Controls.Add(this.Price_label);
            this.Controls.Add(this.Else_label);
            this.Controls.Add(this.Else_textBox);
            this.Controls.Add(this.Price_textBox);
            this.Controls.Add(this.Item_label);
            this.Controls.Add(this.Class_comboBox);
            this.Controls.Add(this.Class_label);
            this.Controls.Add(this.Item_textBox);
            this.Controls.Add(this.Year_comboBox);
            this.Controls.Add(this.budget_progressBar);
            this.Controls.Add(this.Perform_textBox);
            this.Controls.Add(this.data_chart);
            this.Controls.Add(this.Class_dataGridView);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.Game_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClassSetting_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Budget_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Statistic_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cust_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Search_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Add_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Setting_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Class_dataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.記帳BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.data_chart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox Item_textBox;
        private System.Windows.Forms.Label Class_label;
        private System.Windows.Forms.ComboBox Class_comboBox;
        private System.Windows.Forms.Label Item_label;
        private System.Windows.Forms.TextBox Price_textBox;
        private System.Windows.Forms.TextBox Else_textBox;
        private System.Windows.Forms.Label Else_label;
        private System.Windows.Forms.Label Price_label;
        private System.Windows.Forms.TextBox Perform_textBox;
        private System.Windows.Forms.ComboBox Year_comboBox;
        private System.Windows.Forms.ComboBox Month_comboBox;
        private System.Windows.Forms.ComboBox Day_comboBox;
        private System.Windows.Forms.Label Year_label;
        private System.Windows.Forms.Label Day_label;
        private System.Windows.Forms.Label Month_label;
        private System.Windows.Forms.Label Time_label;
        private System.Windows.Forms.Label Search_label;
        private System.Windows.Forms.Label Statistic_label;
        private System.Windows.Forms.Label Game_label;
        private System.Windows.Forms.Label Cust_label;
        private System.Windows.Forms.Label Budget_label;
        private System.Windows.Forms.Label ClassSetting_label;
        private System.Windows.Forms.Label Line1_label;
        private System.Windows.Forms.Label Title_label;
        private System.Windows.Forms.PictureBox Setting_pictureBox;
        private System.Windows.Forms.PictureBox Add_pictureBox;
        private System.Windows.Forms.Button Back_btn;
        private System.Windows.Forms.PictureBox Search_pictureBox;
        private System.Windows.Forms.PictureBox Cust_pictureBox;
        private System.Windows.Forms.PictureBox Statistic_pictureBox;
        private System.Windows.Forms.PictureBox Budget_pictureBox;
        private System.Windows.Forms.PictureBox ClassSetting_pictureBox;
        private System.Windows.Forms.PictureBox Game_pictureBox;
        private System.Windows.Forms.DataGridView Class_dataGridView;
        private trackDataSet trackDataSet;
        private System.Windows.Forms.BindingSource 記帳BindingSource;
        private trackDataSetTableAdapters.記帳TableAdapter 記帳TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn 類別DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 品項DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 價格DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 年DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 月DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 日DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 備註DataGridViewTextBoxColumn;
        private System.Windows.Forms.CheckBox class_checkbox;
        private System.Windows.Forms.Label font_label;
        private System.Windows.Forms.Label color_label;
        private System.Windows.Forms.Label example_label;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.Label delete_class;
        private System.Windows.Forms.Label sort_class;
        private System.Windows.Forms.ComboBox Sort_comboBox;
        private System.Windows.Forms.Label label_sort_exp1;
        private System.Windows.Forms.Label label_sort_exp2;
        private System.Windows.Forms.DataVisualization.Charting.Chart data_chart;
        private System.Windows.Forms.RadioButton Pie_radioButtom;
        private System.Windows.Forms.RadioButton Bar_radioButtom;
        private System.Windows.Forms.RadioButton Line_radioButtom;
        private System.Windows.Forms.RadioButton Histogram_radioButtom;
        private System.Windows.Forms.TextBox budget_textbox;
        private System.Windows.Forms.Button set_budget_buttom;
        private System.Windows.Forms.Label current_month_budget;
        private System.Windows.Forms.Label budgetSet_label;
        private System.Windows.Forms.Label money1;
        private System.Windows.Forms.Label money2;
        private System.Windows.Forms.ProgressBar budget_progressBar;
        private System.Windows.Forms.Label ProgressBar_label;
    }
}

